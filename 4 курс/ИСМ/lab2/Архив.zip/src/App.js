import React from 'react';
import MainView from './component/MainView';
import '../src/styles/index.css'
import '../src/styles/bootstrap.css'

function App() {
  return (
    <MainView />
  );
}

export default App;
